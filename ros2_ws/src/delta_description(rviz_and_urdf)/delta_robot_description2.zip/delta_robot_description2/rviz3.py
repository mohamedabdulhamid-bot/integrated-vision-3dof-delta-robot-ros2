import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from visualization_msgs.msg import Marker
import math
import threading
import sys

class DeltaRobotController(Node):
    def __init__(self):
        super().__init__('delta_ik_node')
        
        # ROS 2 Publishers
        self.joint_pub = self.create_publisher(JointState, 'joint_states', 10)
        self.marker_pub = self.create_publisher(Marker, 'end_effector_marker', 10)
        
        # Robot Physical Parameters (Meters)
        self.sb = 30.2 / 100.0  # Base side
        self.sp = 9.0 / 100.0   # Platform side
        self.L = 32.0 / 100.0   # Active Link (AL)
        self.l = 90.0 / 100.0   # Passive Link (PL)

        # Geometric Constants
        self.wb = self.sb * math.sqrt(3) / 6.0
        self.up = self.sp * math.sqrt(3) / 3.0
        self.wp = self.sp * math.sqrt(3) / 6.0
        self.a = self.wb - self.up
        self.b = (self.sp / 2.0) - (math.sqrt(3) / 2.0) * self.wb
        self.c = self.wp - 0.5 * self.wb

        # Phase angles for the 3 arms (Radians)
        self.phi = [math.radians(90), math.radians(210), math.radians(330)]

        # Store latest messages to publish continuously for RViz
        self.latest_joint_msg = JointState()
        self.latest_marker_msg = Marker()
        
        # Publish loop at 10Hz (Does not spam terminal, just updates RViz)
        self.timer = self.create_timer(0.1, self.publish_loop)

        # Start background thread for user input
        self.input_thread = threading.Thread(target=self.user_input_loop, daemon=True)
        self.input_thread.start()

        # Initialize with a default home position
        self.get_logger().info("Node started. Initializing default position...")
        self.process_kinematics(0.0, 0.0, -0.8)

    def user_input_loop(self):
        """Background loop to take user X Y Z inputs dynamically."""
        while rclpy.ok():
            try:
                print("\n" + "="*50)
                user_input = input("Enter Target X Y Z (e.g., 0.0 0.0 -0.8): ")
                
                parts = user_input.strip().split()
                if len(parts) == 3:
                    x, y, z = map(float, parts)
                    self.process_kinematics(x, y, z)
                else:
                    print("[ERROR] Invalid format. Please enter exactly 3 numbers separated by spaces.")
            except ValueError:
                print("[ERROR] Please enter valid numbers.")
            except Exception:
                pass # Ignore threading interruptions during shutdown

    def process_kinematics(self, x, y, z):
        """Calculates IK/FK and updates messages for RViz & ESP32."""
        # 1. Inverse Kinematics (IK)
        theta_calc = self.calculate_ik(x, y, z)
        
        if theta_calc is None:
            print(f"\n[WARNING] Target ({x}, {y}, {z}) is OUT of physical workspace!")
            return

        # 2. Forward Kinematics (FK) for Double Check
        fk_result = self.calculate_fk(theta_calc[0], theta_calc[1], theta_calc[2])
        
        if fk_result is None:
            print("\n[WARNING] FK calculation failed for these angles.")
            return

        # 3. ESP32 Hardware Angles (Hardware 0 is vertical, Math 0 is horizontal)
        math_degrees = [math.degrees(t) for t in theta_calc]
        esp_angles = [deg + 90.0 for deg in math_degrees]

        # Print detailed report to terminal
        print("\n--- KINEMATICS REPORT ---")
        print(f"Target XYZ   : ({x:.3f}, {y:.3f}, {z:.3f})")
        print(f"FK Calc XYZ  : ({fk_result[0]:.3f}, {fk_result[1]:.3f}, {fk_result[2]:.3f})")
        print(f"Math Angles  : M1={math_degrees[0]:.1f}°, M2={math_degrees[1]:.1f}°, M3={math_degrees[2]:.1f}°")
        print(f"ESP32 Angles : M1={esp_angles[0]:.1f}°, M2={esp_angles[1]:.1f}°, M3={esp_angles[2]:.1f}°")
        
        # 4. Prepare RViz JointState Message
        self.update_rviz_joints(x, y, z, theta_calc)
        
        # 5. Prepare RViz Marker (End-Effector) Message based on FK
        self.update_rviz_marker(fk_result[0], fk_result[1], fk_result[2])

    def calculate_ik(self, x, y, z):
        """Standard Delta Robot Inverse Kinematics."""
        z_calc = -z  # Adapt Z sign for standard math formulas
        
        theta = [0.0, 0.0, 0.0]
        
        E1 = 2 * self.L * (y + self.a)
        F1 = 2 * z_calc * self.L
        G1 = x**2 + y**2 + z_calc**2 + self.a**2 + self.L**2 + 2*y*self.a - self.l**2
        
        E2 = -self.L * (math.sqrt(3) * (x + self.b) + y + self.c)
        F2 = 2 * z_calc * self.L
        G2 = x**2 + y**2 + z_calc**2 + self.b**2 + self.c**2 + self.L**2 + 2*(x*self.b + y*self.c) - self.l**2
        
        E3 = self.L * (math.sqrt(3) * (x - self.b) - y - self.c)
        F3 = 2 * z_calc * self.L
        G3 = x**2 + y**2 + z_calc**2 + self.b**2 + self.c**2 + self.L**2 + 2*(-x*self.b + y*self.c) - self.l**2

        try:
            # Using (+) before math.sqrt ensures the standard Elbow-Out configuration
            theta[0] = 2 * math.atan((-F1 + math.sqrt(E1**2 + F1**2 - G1**2)) / (G1 - E1))
            theta[1] = 2 * math.atan((-F2 + math.sqrt(E2**2 + F2**2 - G2**2)) / (G2 - E2))
            theta[2] = 2 * math.atan((-F3 + math.sqrt(E3**2 + F3**2 - G3**2)) / (G3 - E3))
            return theta
        except ValueError:
            return None

    def calculate_fk(self, theta1, theta2, theta3):
        """Standard Delta Robot Forward Kinematics."""
        t = self.wb - self.up
        
        y1 = -(t + self.L * math.cos(theta1))
        z1 = -self.L * math.sin(theta1)
        
        y2 = (t + self.L * math.cos(theta2)) * math.sin(math.radians(30))
        x2 = (t + self.L * math.cos(theta2)) * math.cos(math.radians(30))
        z2 = -self.L * math.sin(theta2)
        
        y3 = (t + self.L * math.cos(theta3)) * math.sin(math.radians(30))
        x3 = -(t + self.L * math.cos(theta3)) * math.cos(math.radians(30))
        z3 = -self.L * math.sin(theta3)
        
        dnm = (y2 - y1) * x3 - (y3 - y1) * x2
        
        w1 = y1**2 + z1**2
        w2 = x2**2 + y2**2 + z2**2
        w3 = x3**2 + y3**2 + z3**2
        
        a1 = (z2 - z1) * (y3 - y1) - (z3 - z1) * (y2 - y1)
        b1 = -((w2 - w1) * (y3 - y1) - (w3 - w1) * (y2 - y1)) / 2.0
        
        a2 = -(z2 - z1) * x3 + (z3 - z1) * x2
        b2 = ((w2 - w1) * x3 - (w3 - w1) * x2) / 2.0
        
        a = a1**2 + a2**2 + dnm**2
        b = 2 * (a1 * b1 + a2 * (b2 - y1 * dnm) - z1 * dnm**2)
        c = (b2 - y1 * dnm)**2 + b1**2 + dnm**2 * (z1**2 - self.l**2)
        
        d = b**2 - 4.0 * a * c
        if d < 0:
            return None
            
        z0 = -0.5 * (b + math.sqrt(d)) / a
        x0 = (a1 * z0 + b1) / dnm
        y0 = (a2 * z0 + b2) / dnm
        
        # Return negative Z to match ROS coordinates
        return [x0, y0, -z0]

    def update_rviz_joints(self, target_x, target_y, target_z, theta_calc):
        """Calculates visual offsets and updates the JointState message."""
        elbow_calc = [0.0, 0.0, 0.0]
        
        # Calculate visual elbow angles for RViz
        for i in range(3):
            u_target = target_x * math.cos(self.phi[i]) + target_y * math.sin(self.phi[i])
            u_elbow = self.wb + self.L * math.cos(theta_calc[i])
            z_elbow = self.L * math.sin(theta_calc[i])
            
            u_platform = u_target + self.up
            z_platform = target_z  
            
            delta_u = u_platform - u_elbow
            delta_z = z_platform - z_elbow
            alpha = math.atan2(delta_z, delta_u)
            
            elbow_calc[i] = alpha - theta_calc[i]

        # Apply Visual Calibration Offsets for RViz 
        motor_offset = 0.0  
        motor_dir = 1         
        elbow_offset = 0.0  
        elbow_dir = 1          
        
        msg = JointState()
        msg.name = [
            'motor_1_joint', 'motor_2_joint', 'motor_3_joint',
            'elbow_1_joint', 'elbow_2_joint', 'elbow_3_joint'
        ]
        msg.position = [
            (theta_calc[0] * motor_dir) + motor_offset,
            (theta_calc[1] * motor_dir) + motor_offset,
            (theta_calc[2] * motor_dir) + motor_offset,
            (elbow_calc[0] * elbow_dir) + elbow_offset,
            (elbow_calc[1] * elbow_dir) + elbow_offset,
            (elbow_calc[2] * elbow_dir) + elbow_offset
        ]
        self.latest_joint_msg = msg

    def update_rviz_marker(self, x, y, z):
        """Updates the End-Effector marker based on Forward Kinematics."""
        marker = Marker()
        marker.header.frame_id = "base_link"
        marker.ns = "end_effector"
        marker.id = 0
        marker.type = Marker.CYLINDER  
        marker.action = Marker.ADD
        
        marker.pose.position.x = x
        marker.pose.position.y = y
        marker.pose.position.z = z
        marker.pose.orientation.w = 1.0  
        
        # Dimensions: 12cm diameter, 1cm thickness
        marker.scale.x = 0.12
        marker.scale.y = 0.12
        marker.scale.z = 0.01
        
        marker.color.a = 1.0  
        marker.color.r = 0.0
        marker.color.g = 0.0
        marker.color.b = 1.0
        
        self.latest_marker_msg = marker

    def publish_loop(self):
        """Publishes the latest messages to RViz continuously."""
        # Add current timestamp before publishing
        self.latest_joint_msg.header.stamp = self.get_clock().now().to_msg()
        self.latest_marker_msg.header.stamp = self.get_clock().now().to_msg()
        
        self.joint_pub.publish(self.latest_joint_msg)
        self.marker_pub.publish(self.latest_marker_msg)

def main(args=None):
    rclpy.init(args=args)
    node = DeltaRobotController()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        sys.exit(0)

if __name__ == '__main__':
    main()