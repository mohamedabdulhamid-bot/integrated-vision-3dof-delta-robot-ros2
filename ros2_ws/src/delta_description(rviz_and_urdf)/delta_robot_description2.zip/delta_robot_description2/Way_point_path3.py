import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray, String
import math
import threading
import sys
import time

class Delta(Node):
    def __init__(self):
        super().__init__('delta_node')
        
        # Publishers for Serial Bridge Node
        self.angle_pub = self.create_publisher(Float32MultiArray, '/target_angles', 10)
        self.valve_pub = self.create_publisher(String, '/valve_cmd', 10)
        
        # Robot Physical Parameters (in Meters)
        self.sb = 0.60286
        self.sp = 0.10392     
        self.L = 0.32  
        self.l = 0.9  

        # Geometric Constants
        self.wb = self.sb * math.sqrt(3) / 6.0
        self.up = self.sp * math.sqrt(3) / 3.0
        self.wp = self.sp * math.sqrt(3) / 6.0
        self.a = self.wb - self.up
        self.b = (self.sp / 2.0) - (math.sqrt(3) / 2.0) * self.wb
        self.c = self.wp - 0.5 * self.wb

        # --- Calibration Parameters (Sim-to-Real Gap Tuning) ---
        self.X_SCALE = 1.0 
        self.Y_SCALE = 1.0
        self.Z_SCALE = 1.0
        
        self.X_OFFSET = 0.0 
        self.Y_OFFSET = 0.0
        self.Z_OFFSET = 0.0
        
        self.HARDWARE_OFFSET = 68.0  
        self.DIRECTION_MULTIPLIER = 1.0  

        # --- Trapezoidal Velocity Profile Configuration ---
        self.current_pose = [0.0, 0.0, -0.6]  # Default starting position
        self.start_pose = [0.0, 0.0, -0.6]
        self.target_pose = [0.0, 0.0, -0.6]
        
        # Speed settings
        self.max_step = 0.015      
        self.min_step = 0.002      
        self.ramp_distance = 0.04  
        
        self.total_distance = 0.0
        self.is_moving = False
        
        # Timer running at 50Hz (0.02 seconds)
        self.timer = self.create_timer(0.02, self.trajectory_callback)

        # Start background thread for user input
        self.input_thread = threading.Thread(target=self.user_input_loop, daemon=True)
        self.input_thread.start()

        self.get_logger().info("Delta Node with Task Automation Started...")

    def move_to(self, x, y, z, wait_time=0.5):
        """Blocking function to move the robot to a target and wait until it reaches."""
        # Prevent overlapping commands
        while self.is_moving:
            time.sleep(0.05)
            
        self.process_and_publish(x, y, z, publish=False, print_report=True)
        self.start_pose = list(self.current_pose)
        self.target_pose = [x, y, z]
        
        dx = x - self.start_pose[0]
        dy = y - self.start_pose[1]
        dz = z - self.start_pose[2]
        self.total_distance = math.sqrt(dx**2 + dy**2 + dz**2)
        
        self.is_moving = True
        print(f"\n[Trajectory] Moving to ({x}, {y}, {z})...")
        
        # Wait until the math trajectory finishes
        while self.is_moving:
            time.sleep(0.05)
            
        # Add explicit mechanical settling time (Delay after reaching target)
        if wait_time > 0:
            print(f"[Trajectory] Settling at target for {wait_time} seconds...")
            time.sleep(wait_time)

    def set_valve(self, state):
        """Controls the solenoid valve and adds a small delay for pneumatic action."""
        msg = String()
        if state == 1:
            msg.data = "V1"
            print("[END EFFECTOR] Valve ON (Suction)")
        else:
            msg.data = "V0"
            print("[END EFFECTOR] Valve OFF (Release)")
        
        self.valve_pub.publish(msg)
        time.sleep(0.6) # Delay to allow vacuum to build or release

    def run_auto_sequence(self):
        """Executes the full Pick and Place sequence for 3 plates."""
        # Define Coordinates
        plates_x = [-0.2, 0.0, 0.2]
        plates_y = -0.2
        
        boxes_x = [-0.2, 0.0, 0.2]
        boxes_y = 0.4
        
        safe_z = -0.5
        pick_z = -0.6
        
        print("\n[AUTO TASK] Starting Production Line Sequence...")
        
        for i in range(3):
            px = plates_x[i]
            bx = boxes_x[i]
            
            print(f"\n--- Processing Plate {i+1} ---")
            # 1. Hover above plate
            self.move_to(px, plates_y, safe_z, wait_time=0.3)
            
            # 2. Go down to plate
            self.move_to(px, plates_y, pick_z, wait_time=0.5)
            
            # 3. Turn ON Valve
            self.set_valve(1)
            
            # 4. Lift to safe height
            self.move_to(px, plates_y, safe_z, wait_time=0.2)
            
            # 5. Go to Homing Point (0,0,-0.6)
            self.move_to(0.0, 0.0, safe_z, wait_time=0.2)
            
            # 6. Hover above box
            self.move_to(bx, boxes_y, safe_z, wait_time=0.3)
            
            # 7. Go down to box
            self.move_to(bx, boxes_y, pick_z, wait_time=0.5)
            
            # 8. Turn OFF Valve
            self.set_valve(0)
            
            # 9. Lift back to safe height
            self.move_to(bx, boxes_y, safe_z, wait_time=0.2)
            
        # Return to Absolute Home after sequence completion
        self.move_to(0.0, 0.0, safe_z, wait_time=1.0)
        print("\n[AUTO TASK] Production Line Sequence Complete! Ready for next command.")

    def user_input_loop(self):
        """Background loop to take user commands dynamically."""
        while rclpy.ok():
            try:
                print("\n" + "="*50)
                user_input = input("Enter X Y Z, 'V 1'/'V 0', or 'AUTO' for sequence: ")
                
                parts = user_input.strip().split()
                
                if not parts:
                    continue
                    
                if parts[0].upper() == 'AUTO':
                    if self.is_moving:
                        print("[ERROR] Robot is currently moving. Please wait.")
                    else:
                        # Start sequence in a separate thread to keep terminal responsive
                        threading.Thread(target=self.run_auto_sequence, daemon=True).start()
                        
                elif len(parts) == 3:
                    x, y, z = map(float, parts)
                    # Use the standard delay of 0.5s for manual moves
                    self.move_to(x, y, z, wait_time=0.5)
                    
                elif len(parts) == 2 and parts[0].upper() == 'V':
                    self.set_valve(int(parts[1]))
                else:
                    print("[ERROR] Invalid format. Use 'X Y Z', 'V 1', 'V 0', or 'AUTO'.")
                    
            except ValueError:
                print("[ERROR] Please enter valid numbers.")
            except Exception as e:
                print(f"[ERROR] {e}")

    def trajectory_callback(self):
        if not self.is_moving:
            return

        dx = self.target_pose[0] - self.current_pose[0]
        dy = self.target_pose[1] - self.current_pose[1]
        dz = self.target_pose[2] - self.current_pose[2]
        distance_to_target = math.sqrt(dx**2 + dy**2 + dz**2)
        
        distance_from_start = self.total_distance - distance_to_target

        if distance_to_target > 0.001: 
            actual_ramp = min(self.ramp_distance, self.total_distance / 2.0)
            
            if distance_from_start < actual_ramp:
                factor = distance_from_start / actual_ramp
                current_step = self.min_step + (self.max_step - self.min_step) * factor
                
            elif distance_to_target < actual_ramp:
                factor = distance_to_target / actual_ramp
                current_step = self.min_step + (self.max_step - self.min_step) * factor
                
            else:
                current_step = self.max_step

            if distance_to_target <= current_step:
                self.current_pose = list(self.target_pose)
            else:
                self.current_pose[0] += (dx / distance_to_target) * current_step
                self.current_pose[1] += (dy / distance_to_target) * current_step
                self.current_pose[2] += (dz / distance_to_target) * current_step
            
            self.process_and_publish(self.current_pose[0], self.current_pose[1], self.current_pose[2], publish=True, print_report=False)
        else:
            if self.is_moving:
                self.is_moving = False

    def process_and_publish(self, x, y, z, publish=True, print_report=False):
        x_calibrated = (x * self.X_SCALE) + self.X_OFFSET
        y_calibrated = (y * self.Y_SCALE) + self.Y_OFFSET
        Z_calibrated = (z * self.Z_SCALE) + self.Z_OFFSET
        
        math_x = -x_calibrated
        math_y = -y_calibrated
        
        theta_calc = self.calculate_ik(math_x, math_y, Z_calibrated)
        
        if theta_calc is None:
            if print_report: print(f"\n[WARNING] Target ({x}, {y}, {z}) is OUT of physical workspace!")
            return

        fk_math = self.calculate_fk(theta_calc[0], theta_calc[1], theta_calc[2])
        if fk_math is None:
            if print_report: print("\n[WARNING] FK calculation failed.")
            return
            
        fk_real_x = -fk_math[0]
        fk_real_y = -fk_math[1]
        fk_real_z = fk_math[2]

        esp_angles = [0.0, 0.0, 0.0]
        esp_angles[0] = (math.degrees(theta_calc[2]) * self.DIRECTION_MULTIPLIER) + self.HARDWARE_OFFSET
        esp_angles[1] = (math.degrees(theta_calc[1]) * self.DIRECTION_MULTIPLIER) + self.HARDWARE_OFFSET
        esp_angles[2] = (math.degrees(theta_calc[0]) * self.DIRECTION_MULTIPLIER) + self.HARDWARE_OFFSET
        print(f'{esp_angles[0]},{esp_angles[1]},{esp_angles[2]}')

        if publish:
            msg = Float32MultiArray()
            msg.data = [float(esp_angles[0]), float(esp_angles[1]), float(esp_angles[2])]
            self.angle_pub.publish(msg)

        if print_report:
            print("\n--- HARDWARE KINEMATICS REPORT ---")
            print(f"Original Target : ({x:.3f}, {y:.3f}, {z:.3f}) meters")
            print(f"Math Angles     : M1={math.degrees(theta_calc[0]):.1f}°, M2={math.degrees(theta_calc[1]):.1f}°, M3={math.degrees(theta_calc[2]):.1f}°")

    def calculate_ik(self, x, y, z):
        theta = [0.0, 0.0, 0.0]
        E1 = 2 * self.L * (y + self.a)
        F1 = 2 * z * self.L
        G1 = x**2 + y**2 + z**2 + self.a**2 + self.L**2 + 2*y*self.a - self.l**2
        E2 = -self.L * (math.sqrt(3) * (x + self.b) + y + self.c)
        F2 = 2 * z * self.L
        G2 = x**2 + y**2 + z**2 + self.b**2 + self.c**2 + self.L**2 + 2*(x*self.b + y*self.c) - self.l**2
        E3 = self.L * (math.sqrt(3) * (x - self.b) - y - self.c)
        F3 = 2 * z * self.L
        G3 = x**2 + y**2 + z**2 + self.b**2 + self.c**2 + self.L**2 + 2*(-x*self.b + y*self.c) - self.l**2
        try:
            theta[0] = 2 * math.atan((-F1 - math.sqrt(E1**2 + F1**2 - G1**2)) / (G1 - E1))
            theta[1] = 2 * math.atan((-F2 - math.sqrt(E2**2 + F2**2 - G2**2)) / (G2 - E2))
            theta[2] = 2 * math.atan((-F3 - math.sqrt(E3**2 + F3**2 - G3**2)) / (G3 - E3))
            return theta
        except ValueError:
            return None

    def calculate_fk(self, theta1, theta2, theta3):
        t = self.wb - self.up
        y1 = -(t + self.L * math.cos(theta1))
        z1 = -self.L * math.sin(theta1)
        y2 = (t + self.L * math.cos(theta2)) * math.sin(math.radians(30))
        x2 = (t + self.L * math.cos(theta2)) * math.cos(math.radians(30))
        z2 = -self.L * math.sin(theta2)
        y3 = (t + self.L * math.cos(theta3)) * math.sin(math.radians(30))
        x3 = -(t + self.L * math.cos(theta3)) * math.cos(math.radians(30))
        z3 = -self.L * math.sin(theta3)
        dnm = (y2 - y1) * x3 - (y3 - y1) * x2
        w1 = y1**2 + z1**2
        w2 = x2**2 + y2**2 + z2**2
        w3 = x3**2 + y3**2 + z3**2
        a1 = (z2 - z1) * (y3 - y1) - (z3 - z1) * (y2 - y1)
        b1 = -((w2 - w1) * (y3 - y1) - (w3 - w1) * (y2 - y1)) / 2.0
        a2 = -(z2 - z1) * x3 + (z3 - z1) * x2
        b2 = ((w2 - w1) * x3 - (w3 - w1) * x2) / 2.0
        a = a1**2 + a2**2 + dnm**2
        b = 2 * (a1 * b1 + a2 * (b2 - y1 * dnm) - z1 * dnm**2)
        c = (b2 - y1 * dnm)**2 + b1**2 + dnm**2 * (z1**2 - self.l**2)
        d = b**2 - 4.0 * a * c
        if d < 0: return None
        z0 = -0.5 * (b + math.sqrt(d)) / a
        x0 = (a1 * z0 + b1) / dnm
        y0 = (a2 * z0 + b2) / dnm
        return [x0, y0, z0]

def main(args=None):
    rclpy.init(args=args)
    node = Delta()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        sys.exit(0)

if __name__ == '__main__':
    main()