import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class CameraProcessor(Node):
    def __init__(self):
        super().__init__('camera_processor')
        # Publish the processed video feed
        self.publisher_ = self.create_publisher(Image, 'processed_frames', 10)
        
        # Run at ~30 frames per second
        self.timer = self.create_timer(0.033, self.timer_callback) 
        
        # Initialize camera (Change '0' to your external camera's ID, e.g., 2)
        self.cap = cv2.VideoCapture(0)
        self.bridge = CvBridge()

    def timer_callback(self):
        ret, frame = self.cap.read()
        if ret:
            # --- START IMAGE PROCESSING ---
            # Example: Convert to grayscale
            # This is where you will add HSV thresholding or contour detection
            processed_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # --- END IMAGE PROCESSING ---

            # Convert the OpenCV image back to a ROS 2 message
            # Note: use "mono8" for grayscale, or "bgr8" if you keep it in color
            ros_image = self.bridge.cv2_to_imgmsg(processed_frame, encoding="mono8")
            
            # Publish to the ROS network
            self.publisher_.publish(ros_image)

            # Display locally on Ubuntu for debugging
            cv2.imshow("External Camera - Live Feed", processed_frame)
            cv2.waitKey(1)
        else:
            self.get_logger().warn("Failed to grab frame. Check camera connection.")

    def destroy_node(self):
        # Clean up the camera resource when shutting down
        self.cap.release()
        cv2.destroyAllWindows()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = CameraProcessor()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()