import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import math

class DeltaRobotIK(Node):
    def __init__(self):
        super().__init__('delta_ik_node')
        self.publisher_ = self.create_publisher(JointState, 'joint_states', 10)
        self.timer = self.create_timer(0.1, self.timer_callback)

        # الأبعاد الفيزيائية (محولة من سم إلى متر لتتوافق مع ROS 2)
        self.sb = 0.302 # Base side
        self.sp = 0.09  # Platform side
        self.L = 32.0 / 100.0   # Active Link (AL)
        self.l = 90.0 / 100.0   # Passive Link (PL)

        # حسابات ثوابت المثلثات الهندسية
        self.wb = self.sb * math.sqrt(3) / 6.0
        self.up = self.sp * math.sqrt(3) / 3.0
        self.wp = self.sp * math.sqrt(3) / 6.0

        self.a = self.wb - self.up
        self.b = (self.sp / 2.0) - (math.sqrt(3) / 2.0) * self.wb
        self.c = self.wp - 0.5 * self.wb

        # زوايا توزيع الدراعات الثلاثة حول محور Z (بالراديان)
        self.phi = [math.radians(90), math.radians(210), math.radians(330)]

    def timer_callback(self):
        # النقطة المطلوبة (Target Point) - تقدر تغير Z لاختبار العمق
        target_x = 0.0
        target_y = 0.0
        target_z = -0.70
        
        # 1. حساب زوايا المواتير الأساسية من معادلات IK
        angles = self.calculate_ik(target_x, target_y, target_z)
        
        if angles is None:
            self.get_logger().warn('Target point is Out of Workspace!')
            return
            
        theta_calc = angles  # الزوايا الهندسية الصافية بالراديان
        
        # 2. حساب زوايا الكيعان (Elbows) بصرياً لمحاكي RViz
        elbow_calc = [0.0, 0.0, 0.0]
        for i in range(3):
            u_target = target_x * math.cos(self.phi[i]) + target_y * math.sin(self.phi[i])
            u_elbow = self.wb + self.L * math.cos(theta_calc[i])
            z_elbow = self.L * math.sin(theta_calc[i])
            
            u_platform = u_target + self.up
            z_platform = -target_z  # بنعكسها هنا عشان تتوافق مع الإسقاط الرياضي
            
            delta_u = u_platform - u_elbow
            delta_z = z_platform - z_elbow
            alpha = math.atan2(delta_z, delta_u)
            
            elbow_calc[i] = alpha - theta_calc[i]

        # 3. المعايرة البرمجية لمطابقة وضع السوليدوركس (RViz Calibration)
        vertical_offset = 0.458 
        direction = -1  # لو لقيت الدراعات بتطلع لفوق بدل ما تنزل، غير الرقم ده لـ -1
        
        # 4. تطبيق التشفيت والمعايرة (Motor & Elbow Mapping 1->2, 2->3, 3->1)
        theta1_out = (theta_calc[1] * direction) + vertical_offset
        theta2_out = (theta_calc[2] * direction) + vertical_offset
        theta3_out = (theta_calc[0] * direction) + vertical_offset
        
        elbow1_out = 0.0
        elbow2_out = 0.0
        elbow3_out = 0.0
        
        # 5. إرسال البيانات كاملة لـ RViz
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        
        msg.name = [
            'motor_1_joint', 'motor_2_joint', 'motor_3_joint',
            'elbow_1_joint', 'elbow_2_joint', 'elbow_3_joint'
        ]
        msg.position = [
            theta1_out, theta2_out, theta3_out,
            elbow1_out, elbow2_out, elbow3_out
        ]
        
        self.publisher_.publish(msg)

    def calculate_ik(self, x, y, z):
        # عكس إشارة Z لتتوافق معادلات الورقة البحثية (الموجب لأسفل) مع نظام ROS
        z_calc = -z
        
        theta = [0.0, 0.0, 0.0]
        
        E1 = 2 * self.L * (y + self.a)
        F1 = 2 * z_calc * self.L
        G1 = x**2 + y**2 + z_calc**2 + self.a**2 + self.L**2 + 2*y*self.a - self.l**2
        
        E2 = -self.L * (math.sqrt(3) * (x + self.b) + y + self.c)
        F2 = 2 * z_calc * self.L
        G2 = x**2 + y**2 + z_calc**2 + self.b**2 + self.c**2 + self.L**2 + 2*(x*self.b + y*self.c) - self.l**2
        
        E3 = self.L * (math.sqrt(3) * (x - self.b) - y - self.c)
        F3 = 2 * z_calc * self.L
        G3 = x**2 + y**2 + z_calc**2 + self.b**2 + self.c**2 + self.L**2 + 2*(-x*self.b + y*self.c) - self.l**2

        try:
            theta[0] = 2 * math.atan((-F1 - math.sqrt(E1**2 + F1**2 - G1**2)) / (G1 - E1))
            theta[1] = 2 * math.atan((-F2 - math.sqrt(E2**2 + F2**2 - G2**2)) / (G2 - E2))
            theta[2] = 2 * math.atan((-F3 - math.sqrt(E3**2 + F3**2 - G3**2)) / (G3 - E3))
            return theta
        except ValueError:
            return None

def main(args=None):
    rclpy.init(args=args)
    ik_node = DeltaRobotIK()
    rclpy.spin(ik_node)
    ik_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()