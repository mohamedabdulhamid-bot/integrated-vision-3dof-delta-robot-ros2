import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray, String
import math
import threading
import sys
import time

class Delta(Node):
    def __init__(self):
        super().__init__('delta_node')
        
        # Publishers for Serial Bridge Node
        self.angle_pub = self.create_publisher(Float32MultiArray, '/target_angles', 10)
        self.valve_pub = self.create_publisher(String, '/valve_cmd', 10)
        
        # Robot Physical Parameters (in Meters) - DO NOT CHANGE
        self.sb = 0.60286
        self.sp = 0.10392     
        self.L = 0.32  
        self.l = 0.9  

        # Geometric Constants
        self.wb = self.sb * math.sqrt(3) / 6.0
        self.up = self.sp * math.sqrt(3) / 3.0
        self.wp = self.sp * math.sqrt(3) / 6.0
        self.a = self.wb - self.up
        self.b = (self.sp / 2.0) - (math.sqrt(3) / 2.0) * self.wb
        self.c = self.wp - 0.5 * self.wb

        # --- Calibration Parameters ---
        # ALL SCALES RESET TO 1.0 TO FIX THE Z-DROPPING (BOWL EFFECT)
        self.X_SCALE = 1.0 
        self.Y_SCALE = 1.0 
        self.Z_SCALE = 1.0 
        
        self.X_OFFSET = 0.0 
        self.Y_OFFSET = 0.0
        self.Z_OFFSET = 0.0
        
        # Perfected offset based on your real physical measurements
        self.HARDWARE_OFFSET = 68.0  
        self.DIRECTION_MULTIPLIER = 1.0  

        # --- Trapezoidal Velocity Profile Configuration ---
        self.current_pose = [0.0, 0.0, -0.6]  
        self.start_pose = [0.0, 0.0, -0.6]
        self.target_pose = [0.0, 0.0, -0.6]
        
        # Speed settings
        self.max_step = 0.015      
        self.min_step = 0.002      
        self.ramp_distance = 0.04  
        
        self.total_distance = 0.0
        self.is_moving = False
        
        self.timer = self.create_timer(0.02, self.trajectory_callback)
        self.input_thread = threading.Thread(target=self.user_input_loop, daemon=True)
        self.input_thread.start()

        self.get_logger().info("Delta Node Started. Z-Bowl Effect Fixed!")

    def move_to(self, x, y, z, wait_time=0.5):
        """Blocking function to move the robot to a target and wait until it reaches."""
        while self.is_moving:
            time.sleep(0.05)
            
        self.process_and_publish(x, y, z, publish=False, print_report=True)
        self.start_pose = list(self.current_pose)
        self.target_pose = [x, y, z]
        
        dx = x - self.start_pose[0]
        dy = y - self.start_pose[1]
        dz = z - self.start_pose[2]
        self.total_distance = math.sqrt(dx**2 + dy**2 + dz**2)
        
        self.is_moving = True
        print(f"\n[Trajectory] Moving to ({x}, {y}, {z})...")
        
        while self.is_moving:
            time.sleep(0.05)
            
        if wait_time > 0:
            time.sleep(wait_time)

    def set_valve(self, state):
        msg = String()
        if state == 1:
            msg.data = "V1"
            print("[END EFFECTOR] Valve ON (Suction)")
        else:
            msg.data = "V0"
            print("[END EFFECTOR] Valve OFF (Release)")
        
        self.valve_pub.publish(msg)
        time.sleep(0.6) 

    def run_auto_sequence(self):
        plates_x = [-0.3, 0.0, 0.3]
        plates_y = -0.2
        boxes_x = [-0.3, 0.0, 0.3]
        boxes_y = 0.2
        
        safe_z = -0.57
        pick_z = -0.6
        release_z = -0.7
        
        print("\n[AUTO TASK] Starting Production Line Sequence...")
        for j in range(7):
            for i in range(3):
                px = plates_x[i]
                bx = boxes_x[i]
                
                print(f"\n--- Processing Plate {i+1} (Cycle {j+1}) ---")
                self.move_to(px, plates_y, safe_z, wait_time=0.3)
                self.move_to(px, plates_y, pick_z, wait_time=0.5)
                self.set_valve(1)
                self.move_to(px, plates_y, safe_z, wait_time=0.2)
                self.move_to(0.0, 0.0, safe_z, wait_time=0.2)
                self.move_to(bx, boxes_y, safe_z, wait_time=0.3)
                self.move_to(bx, boxes_y, release_z, wait_time=0.5)
                self.set_valve(0)
                self.move_to(bx, boxes_y, safe_z, wait_time=0.2)
                
            self.move_to(0.0, 0.0, safe_z, wait_time=1.0)
        print("\n[AUTO TASK] Production Line Sequence Complete!")

    def user_input_loop(self):
        while rclpy.ok():
            try:
                print("\n" + "="*50)
                user_input = input("Enter X Y Z, 'V 1'/'V 0', or 'AUTO': ")
                parts = user_input.strip().split()
                if not parts: continue
                    
                if parts[0].upper() == 'AUTO':
                    if self.is_moving: print("[ERROR] Robot is moving.")
                    else: threading.Thread(target=self.run_auto_sequence, daemon=True).start()
                elif len(parts) == 3:
                    x, y, z = map(float, parts)
                    self.move_to(x, y, z, wait_time=0.5)
                elif len(parts) == 2 and parts[0].upper() == 'V':
                    self.set_valve(int(parts[1]))
            except ValueError:
                print("[ERROR] Please enter valid numbers.")
            except Exception: pass

    def trajectory_callback(self):
        if not self.is_moving: return
        dx = self.target_pose[0] - self.current_pose[0]
        dy = self.target_pose[1] - self.current_pose[1]
        dz = self.target_pose[2] - self.current_pose[2]
        dist = math.sqrt(dx**2 + dy**2 + dz**2)
        dist_start = self.total_distance - dist

        if dist > 0.001: 
            ramp = min(self.ramp_distance, self.total_distance / 2.0)
            if dist_start < ramp: step = self.min_step + (self.max_step - self.min_step) * (dist_start / ramp)
            elif dist < ramp: step = self.min_step + (self.max_step - self.min_step) * (dist / ramp)
            else: step = self.max_step

            if dist <= step: self.current_pose = list(self.target_pose)
            else:
                self.current_pose[0] += (dx / dist) * step
                self.current_pose[1] += (dy / dist) * step
                self.current_pose[2] += (dz / dist) * step
            
            self.process_and_publish(self.current_pose[0], self.current_pose[1], self.current_pose[2], publish=True, print_report=False)
        else:
            if self.is_moving: self.is_moving = False

    def process_and_publish(self, x, y, z, publish=True, print_report=False):
        math_x = x
        math_y = y
        
        # Absolute boundary to prevent physical crashing
        safe_z = z
        if safe_z > -0.57:
            safe_z = -0.57
            
        theta_calc = self.calculate_ik(math_x, math_y, safe_z)
        
        if theta_calc is None:
            if print_report: print(f"\n[WARNING] Target ({x}, {y}, {z}) is UNREACHABLE!")
            return

        esp_angles = [0.0, 0.0, 0.0]
        
        # --- THE FIX: Correct Hardware Mapping derived from your Table ---
        # Your table showed M3 reacts mostly to Y axis. Theta[0] is the Y-axis math calculation.
        esp_angles[2] = (math.degrees(theta_calc[0]) * self.DIRECTION_MULTIPLIER) + self.HARDWARE_OFFSET # Motor 3
        esp_angles[1] = (math.degrees(theta_calc[1]) * self.DIRECTION_MULTIPLIER) + self.HARDWARE_OFFSET # Motor 2
        esp_angles[0] = (math.degrees(theta_calc[2]) * self.DIRECTION_MULTIPLIER) + self.HARDWARE_OFFSET # Motor 1

        if publish:
            msg = Float32MultiArray()
            msg.data = [float(esp_angles[0]), float(esp_angles[1]), float(esp_angles[2])]
            self.angle_pub.publish(msg)

        if print_report:
            print("\n--- HARDWARE KINEMATICS REPORT ---")
            print(f"Target : ({x:.3f}, {y:.3f}, {z:.3f}) meters")
            print(f"ESP32  : M1={esp_angles[0]:.2f}°, M2={esp_angles[1]:.2f}°, M3={esp_angles[2]:.2f}°")

    def calculate_ik(self, x, y, z):
        theta = [0.0, 0.0, 0.0]
        E1 = 2 * self.L * (y + self.a)
        F1 = 2 * z * self.L
        G1 = x**2 + y**2 + z**2 + self.a**2 + self.L**2 + 2*y*self.a - self.l**2
        E2 = -self.L * (math.sqrt(3) * (x + self.b) + y + self.c)
        F2 = 2 * z * self.L
        G2 = x**2 + y**2 + z**2 + self.b**2 + self.c**2 + self.L**2 + 2*(x*self.b + y*self.c) - self.l**2
        E3 = self.L * (math.sqrt(3) * (x - self.b) - y - self.c)
        F3 = 2 * z * self.L
        G3 = x**2 + y**2 + z**2 + self.b**2 + self.c**2 + self.L**2 + 2*(-x*self.b + y*self.c) - self.l**2
        try:
            theta[0] = 2 * math.atan((-F1 - math.sqrt(E1**2 + F1**2 - G1**2)) / (G1 - E1))
            theta[1] = 2 * math.atan((-F2 - math.sqrt(E2**2 + F2**2 - G2**2)) / (G2 - E2))
            theta[2] = 2 * math.atan((-F3 - math.sqrt(E3**2 + F3**2 - G3**2)) / (G3 - E3))
            return theta
        except ValueError:
            return None

def main(args=None):
    rclpy.init(args=args)
    node = Delta()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        sys.exit(0)

if __name__ == '__main__':
    main()