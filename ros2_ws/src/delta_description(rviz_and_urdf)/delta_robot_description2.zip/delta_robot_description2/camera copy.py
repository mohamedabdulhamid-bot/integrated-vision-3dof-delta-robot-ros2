import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class CameraProcessor(Node):
    def __init__(self):
        super().__init__('camera_processor')
        # Publish the processed video feed
        self.publisher_ = self.create_publisher(Image, 'processed_frames', 10)
        
        # Run at ~30 frames per second
        self.timer = self.create_timer(0.033, self.timer_callback) 
        
        # Initialize camera (Change '0' to your external camera's ID, e.g., 2)
        self.cap = cv2.VideoCapture(0)
        self.bridge = CvBridge()

    def timer_callback(self):
        ret, frame = self.cap.read()
        if ret:
            # --- START IMAGE PROCESSING ---
            # 1. Grayscale and Blur
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)

            # 2. Edge Detection
            edges = cv2.Canny(blurred, 50, 150)

            # 3. Find Contours
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            processed_frame = frame.copy() # Copy to draw overlays on the color feed

            # 4. Analyze Shapes
            for contour in contours:
                area = cv2.contourArea(contour)
                
                # Filter out small noise (adjust this threshold based on camera height)
                if area > 1000: 
                    # Calculate the perimeter to help approximate the shape
                    perimeter = cv2.arcLength(contour, True)
                    approx = cv2.approxPolyDP(contour, 0.02 * perimeter, True)
                    
                    # Determine shape based on vertices
                    shape_name = "Unknown"
                    if len(approx) == 3:
                        shape_name = "Triangle"
                    elif len(approx) == 4:
                        # You can add logic here to distinguish rectangles vs squares using aspect ratio
                        shape_name = "Rectangle"
                    elif len(approx) > 4:
                        shape_name = "Circle/Plate"

                    # Calculate Centroid (Image Moments)
                    M = cv2.moments(contour)
                    if M["m00"] != 0:
                        cX = int(M["m10"] / M["m00"])
                        cY = int(M["m01"] / M["m00"])

                        # Draw the contour, centroid, and text on the frame
                        cv2.drawContours(processed_frame, [approx], -1, (0, 255, 0), 2)
                        cv2.circle(processed_frame, (cX, cY), 5, (0, 0, 255), -1)
                        cv2.putText(processed_frame, f"{shape_name} ({cX}, {cY})", 
                                    (cX - 50, cY - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
            # --- END IMAGE PROCESSING ---
            
            # Note: Since we are publishing a color frame with overlays now, 
            # change the encoding in the publisher to "bgr8"
            ros_image = self.bridge.cv2_to_imgmsg(processed_frame, encoding="bgr8")   # Publish to the ROS network
            self.publisher_.publish(ros_image)

            # Display locally on Ubuntu for debugging
            cv2.imshow("External Camera - Live Feed", processed_frame)
            cv2.waitKey(1)
        else:
            self.get_logger().warn("Failed to grab frame. Check camera connection.")

    def destroy_node(self):
        # Clean up the camera resource when shutting down
        self.cap.release()
        cv2.destroyAllWindows()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = CameraProcessor()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()