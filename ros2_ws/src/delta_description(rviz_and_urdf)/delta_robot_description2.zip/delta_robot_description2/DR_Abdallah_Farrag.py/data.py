#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray, String
import math
import threading
import sys
import time
import csv
from datetime import datetime

class KinematicsNode(Node):
    def __init__(self):
        super().__init__('kinematics_node')
        
        self.angles_pub = self.create_publisher(Float32MultiArray, '/target_angles', 10)
        self.status_sub = self.create_subscription(String, '/robot_status', self.status_callback, 10)
        
        self.robot_done_event = threading.Event()
        
        # Data Logging Variables
        self.is_logging = False
        self.csv_file = None
        self.csv_writer = None
        self.log_start_time = 0.0
        
        # KINEMATIC in (mm) 
        self.f = 602.86  
        self.e = 207.85  
        self.rf = 320.0  
        self.re = 900.0  
        self.horizontal_offset = 50.0
        
        self.ROBOT_SPEED_MM_S = 400.0 
        self.PUBLISH_RATE_HZ = 50.0 
        
        self.current_x = 0.0
        self.current_y = 0.0
        self.current_z = -600.0 
        self.is_first_move = True
        
        self.get_logger().info("Interactive Kinematics Node Started with Data Logger.")
        
        self.cli_thread = threading.Thread(target=self.input_loop, daemon=True)
        self.cli_thread.start()

    def status_callback(self, msg):
        """Listens for DONE signal and DATA records from ESP32."""
        text = msg.data.strip()
        
        if "DONE" in text.upper():
            self.robot_done_event.set()
            
        elif text.startswith("DATA:") and self.is_logging:
            try:
                values_str = text.replace("DATA:", "").split(',')
                if len(values_str) == 6 and self.csv_writer is not None:
                    elapsed_time = time.time() - self.log_start_time
                    row = [f"{elapsed_time:.3f}"] + [float(v) for v in values_str]
                    self.csv_writer.writerow(row)
            except Exception:
                pass

    def run_hypotenuse_test(self):
        """Executes hypotenuse movement and logs data to CSV."""
        print("\n[TEST] Step 1: Moving to Safe Center (0, 0, -450)...")
        self.robot_done_event.clear()
        self.move_smoothly(0.0, 0.0, -450.0)
        self.robot_done_event.wait(timeout=5.0)
        time.sleep(1.0)
        
        filename = f"delta_robot_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        self.csv_file = open(filename, mode='w', newline='')
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow(['Time_s', 'Target_M1', 'Actual_M1', 'Target_M2', 'Actual_M2', 'Target_M3', 'Actual_M3'])
        
        print(f"[TEST] Recording started. Saving to {filename}")
        self.log_start_time = time.time()
        self.is_logging = True
        
        print("[TEST] Step 2: Moving along hypotenuse to far point (150, 150, -700)...")
        self.robot_done_event.clear()
        self.move_smoothly(200.0, 200.0, -700.0)
        
        # Wait longer for the test movement
        self.robot_done_event.wait(timeout=10.0)
        
        # Stop logging
        self.is_logging = False
        if self.csv_file:
            self.csv_file.close()
            
        print(f"\n[TEST COMPLETE] File {filename} is ready for the doctor!")

    def input_loop(self):
        print("\n=================================================")
        print(" DELTA ROBOT DATA LOGGER MENU")
        print("=================================================")
        print("COMMANDS:")
        print("  - Enter X Y Z (e.g., 0 0 -500)")
        print("  - Enter 'test' to run the Hypotenuse Data Logging Test.")
        print("  - Enter 'q' to quit.")
        
        while rclpy.ok():
            try:
                user_input = input("\nEnter Command: ").strip()
                
                if user_input.lower() in ['q', 'quit', 'exit', 'cancel']:
                    if self.csv_file and not self.csv_file.closed:
                        self.csv_file.close()
                    print("Exiting...")
                    rclpy.shutdown()
                    sys.exit(0)
                
                if user_input.lower() == 'test':
                    self.run_hypotenuse_test()
                    continue
                
                numbers = [float(val.strip()) for val in user_input.split(' ')]
                if len(numbers) != 3:
                    print("[!] Invalid format.")
                    continue
                    
                target_x, target_y, target_z = numbers
                
                status, t1_kin, t2_kin, t3_kin = self.inverse_kinematics(target_x, target_y, target_z)
                if status != 0:
                    print(f"\n[ERROR] Target is OUT OF BOUNDS.")
                    continue
                
                print(f">> Moving to X:{target_x} Y:{target_y} Z:{target_z}")
                
                self.robot_done_event.clear()
                self.move_smoothly(target_x, target_y, target_z)
                self.robot_done_event.wait(timeout=5.0)
                print(">> Movement Complete.")
                
            except ValueError:
                print("[!] Invalid input.")
            except Exception as e:
                print(f"[!] Unexpected error: {e}")

    def move_smoothly(self, target_x, target_y, target_z):
        if self.is_first_move:
            self.current_x = target_x
            self.current_y = target_y
            self.current_z = target_z
            self.is_first_move = False
            return self.publish_ik_point(target_x, target_y, target_z)

        x0, y0, z0 = self.current_x, self.current_y, self.current_z
        distance = math.sqrt((target_x - x0)**2 + (target_y - y0)**2 + (target_z - z0)**2)
        
        if distance < 1.0:
            return True

        duration = distance / self.ROBOT_SPEED_MM_S
        steps = int(duration * self.PUBLISH_RATE_HZ)
        if steps < 1: 
            steps = 1
            
        dt = 1.0 / self.PUBLISH_RATE_HZ 

        for i in range(1, steps + 1):
            t_norm = i / steps 
            s = (t_norm ** 2) * (3.0 - 2.0 * t_norm)
            
            ix = x0 + (target_x - x0) * s
            iy = y0 + (target_y - y0) * s
            iz = z0 + (target_z - z0) * s
            
            success = self.publish_ik_point(ix, iy, iz)
            if not success:
                return False
                
            time.sleep(dt)

        self.current_x = target_x
        self.current_y = target_y
        self.current_z = target_z
        return True

    def publish_ik_point(self, x, y, z):
        status, t1, t2, t3 = self.inverse_kinematics(x, y, z)
        if status != 0:
            return False 

        esp_t1 = t1 + self.horizontal_offset
        esp_t2 = t2 + self.horizontal_offset
        esp_t3 = t3 + self.horizontal_offset

        if esp_t1 < 0 or esp_t2 < 0 or esp_t3 < 0:
            return False 

        msg = Float32MultiArray()
        msg.data = [esp_t1, esp_t2, esp_t3]
        self.angles_pub.publish(msg)
        return True

    def inverse_kinematics(self, x0, y0, z0):
        sqrt3 = math.sqrt(3.0)
        sin120 = sqrt3 / 2.0
        cos120 = -0.5
        
        status1, theta1 = self._calc_angle(x0, y0, z0)
        x2 = x0 * cos120 + y0 * sin120
        y2 = y0 * cos120 - x0 * sin120
        status2, theta2 = self._calc_angle(x2, y2, z0)
        
        x3 = x0 * cos120 - y0 * sin120
        y3 = y0 * cos120 + x0 * sin120
        status3, theta3 = self._calc_angle(x3, y3, z0)
        
        if status1 != 0 or status2 != 0 or status3 != 0:
            return -1, 0, 0, 0
            
        return 0, theta1, theta2, theta3

    def _calc_angle(self, x0, y0, z0):
        tan30 = 1.0 / math.sqrt(3.0)
        y1 = -0.5 * tan30 * self.f 
        y0_offset = y0 - 0.5 * tan30 * self.e 
        
        a = (x0**2 + y0_offset**2 + z0**2 + self.rf**2 - self.re**2 - y1**2) / (2.0 * z0)
        b = (y1 - y0_offset) / z0
        
        d = -(a + b * y1)**2 + self.rf**2 * (b**2 + 1)
        
        if d < 0:
            return -1, 0
            
        yj = (y1 - a * b - math.sqrt(d)) / (b**2 + 1)
        zj = a + b * yj
        
        theta = math.degrees(math.atan(-zj / (y1 - yj)))
        if yj > y1:
            theta += 180.0
            
        return 0, theta

def main(args=None):
    rclpy.init(args=args)
    node = KinematicsNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()