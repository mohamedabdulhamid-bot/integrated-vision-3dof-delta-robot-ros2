import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import math
import threading
import sys

class Delta(Node):
    def __init__(self):
        super().__init__('delta_node')
        
        # Publisher for Serial Bridge Node
        self.angle_pub = self.create_publisher(Float32MultiArray, '/target_angles', 10)
        
        # Robot Physical Parameters (in Meters)
        self.sb = 0.60286
        self.sp = 0.20785    
        self.L = 0.32  
        self.l = 0.9  

        # Geometric Constants
        self.wb = self.sb * math.sqrt(3) / 6.0
        self.up = self.sp * math.sqrt(3) / 3.0
        self.wp = self.sp * math.sqrt(3) / 6.0
        self.a = self.wb - self.up
        self.b = (self.sp / 2.0) - (math.sqrt(3) / 2.0) * self.wb
        self.c = self.wp - 0.5 * self.wb

        # --- Calibration Parameters (Sim-to-Real Gap Tuning) ---
        # Scale: If you command 0.2m but it moves 0.18m, set Scale to (0.2/0.18) = 1.11
        self.X_SCALE = 1.0
        self.Y_SCALE = 1.0
        self.Z_SCALE = 1.0
        
        # Offset: If the physical center (0,0) is shifted, adjust these values (in meters)
        self.X_OFFSET = 0.0 
        self.Y_OFFSET = 0.0
        self.Z_OFFSET = 0.0
        

        # Hardware Limit Switch Offset (0 deg physical = math horizontal alignment)
        self.HARDWARE_OFFSET = 49.2 
        self.DIRECTION_MULTIPLIER = 1.0  

        # Start background thread for user input
        self.input_thread = threading.Thread(target=self.user_input_loop, daemon=True)
        self.input_thread.start()

        self.get_logger().info("Delta Node Started. Waiting for input...")

    def user_input_loop(self):
        """Background loop to take user X Y Z inputs dynamically."""
        while rclpy.ok():
            try:
                print("\n" + "="*50)
                user_input = input("Enter Target X Y Z (meters) [e.g., 0.0 0.0 -0.8]: ")
                
                parts = user_input.strip().split()
                if len(parts) == 3:
                    x, y, z = map(float, parts)
                    self.process_and_publish(x, y, z)
                else:
                    print("[ERROR] Invalid format. Please enter exactly 3 numbers separated by spaces.")
            except ValueError:
                print("[ERROR] Please enter valid numbers.")
            except Exception:
                pass 

    def process_and_publish(self, x, y, z):
        """Applies calibration, calculates IK, maps to hardware angles, and publishes."""
        
        # 1. Apply Calibration (Scale and Offset) to the requested inputs
        x_calibrated = (x * self.X_SCALE) + self.X_OFFSET
        y_calibrated = (y * self.Y_SCALE) + self.Y_OFFSET
        Z_calibrated = (z* self.Z_SCALE) + self.Z_OFFSET
        
        # 2. Geometric Correction: Invert X and Y to compensate for the 180-degree physical hardware rotation
        math_x = -x_calibrated
        math_y = -y_calibrated
        
        # 3. Calculate Inverse Kinematics (IK)
        theta_calc = self.calculate_ik(math_x, math_y, Z_calibrated)
        
        if theta_calc is None:
            print(f"\n[WARNING] Target ({x}, {y}, {z}) is OUT of physical workspace!")
            return

        # 4. Calculate Forward Kinematics (FK) and revert inversion for terminal reporting
        fk_math = self.calculate_fk(theta_calc[0], theta_calc[1], theta_calc[2])
        if fk_math is None:
            print("\n[WARNING] FK calculation failed.")
            return
            
        fk_real_x = -fk_math[0]
        fk_real_y = -fk_math[1]
        fk_real_z = fk_math[2]

        # 5. Map mathematical angles to the actual physical motors
        esp_angles = [0.0, 0.0, 0.0]
        
        # New motor distribution matching the physical hardware setup:
        # Math Arm 3 (Top-Left in math) -> Maps to Hardware M1 (Bottom-Right)
        esp_angles[0] = (math.degrees(theta_calc[2]) * self.DIRECTION_MULTIPLIER) + self.HARDWARE_OFFSET
        
        # Math Arm 2 (Top-Right in math) -> Maps to Hardware M2 (Bottom-Left)
        esp_angles[1] = (math.degrees(theta_calc[1]) * self.DIRECTION_MULTIPLIER) + self.HARDWARE_OFFSET
        
        # Math Arm 1 (Bottom in math) -> Maps to Hardware M3 (Top on Y-axis)
        esp_angles[2] = (math.degrees(theta_calc[0]) * self.DIRECTION_MULTIPLIER) + self.HARDWARE_OFFSET

        # 6. Publish angles to the ESP32 via Serial Bridge
        msg = Float32MultiArray()
        msg.data = [float(esp_angles[0]), float(esp_angles[1]), float(esp_angles[2])]
        self.angle_pub.publish(msg)

        # 7. Print Terminal Report
        print("\n--- HARDWARE KINEMATICS REPORT ---")
        print(f"Original Target : ({x:.3f}, {y:.3f}, {z:.3f}) meters")
        print(f"Calibrated Tgt  : ({x_calibrated:.3f}, {y_calibrated:.3f}, {Z_calibrated:.3f}) meters")
        print(f"FK Calc XYZ (actual-->calibrated)    : ({fk_real_x:.3f}, {fk_real_y:.3f}, {fk_real_z:.3f}) meters")
        #to be sure of print the actual postion
        fk_original_z = fk_real_z / self.Z_SCALE
        print(f"FK Calc XYZ     : ({fk_real_x:.3f}, {fk_real_y:.3f}, {fk_original_z:.3f}) meters")
        print(f"Math Angles     : M1={math.degrees(theta_calc[0]):.1f}°, M2={math.degrees(theta_calc[1]):.1f}°, M3={math.degrees(theta_calc[2]):.1f}°")
        print(f"ESP32 Angles    : M1={esp_angles[0]:.1f}°, M2={esp_angles[1]:.1f}°, M3={esp_angles[2]:.1f}°")
        print(f"-> Published to /target_angles")

    def calculate_ik(self, x, y, z):
        """Standard Delta Robot Inverse Kinematics."""
        theta = [0.0, 0.0, 0.0]
        
        E1 = 2 * self.L * (y + self.a)
        F1 = 2 * z * self.L
        G1 = x**2 + y**2 + z**2 + self.a**2 + self.L**2 + 2*y*self.a - self.l**2
        
        E2 = -self.L * (math.sqrt(3) * (x + self.b) + y + self.c)
        F2 = 2 * z * self.L
        G2 = x**2 + y**2 + z**2 + self.b**2 + self.c**2 + self.L**2 + 2*(x*self.b + y*self.c) - self.l**2
        
        E3 = self.L * (math.sqrt(3) * (x - self.b) - y - self.c)
        F3 = 2 * z * self.L
        G3 = x**2 + y**2 + z**2 + self.b**2 + self.c**2 + self.L**2 + 2*(-x*self.b + y*self.c) - self.l**2

        try:
            # Minus root ensures standard Elbow-Out configuration for downward Z
            theta[0] = 2 * math.atan((-F1 - math.sqrt(E1**2 + F1**2 - G1**2)) / (G1 - E1))
            theta[1] = 2 * math.atan((-F2 - math.sqrt(E2**2 + F2**2 - G2**2)) / (G2 - E2))
            theta[2] = 2 * math.atan((-F3 - math.sqrt(E3**2 + F3**2 - G3**2)) / (G3 - E3))
            return theta
        except ValueError:
            return None

    def calculate_fk(self, theta1, theta2, theta3):
        """Standard Delta Robot Forward Kinematics."""
        t = self.wb - self.up
        
        y1 = -(t + self.L * math.cos(theta1))
        z1 = -self.L * math.sin(theta1)
        
        y2 = (t + self.L * math.cos(theta2)) * math.sin(math.radians(30))
        x2 = (t + self.L * math.cos(theta2)) * math.cos(math.radians(30))
        z2 = -self.L * math.sin(theta2)
        
        y3 = (t + self.L * math.cos(theta3)) * math.sin(math.radians(30))
        x3 = -(t + self.L * math.cos(theta3)) * math.cos(math.radians(30))
        z3 = -self.L * math.sin(theta3)
        
        dnm = (y2 - y1) * x3 - (y3 - y1) * x2
        
        w1 = y1**2 + z1**2
        w2 = x2**2 + y2**2 + z2**2
        w3 = x3**2 + y3**2 + z3**2
        
        a1 = (z2 - z1) * (y3 - y1) - (z3 - z1) * (y2 - y1)
        b1 = -((w2 - w1) * (y3 - y1) - (w3 - w1) * (y2 - y1)) / 2.0
        
        a2 = -(z2 - z1) * x3 + (z3 - z1) * x2
        b2 = ((w2 - w1) * x3 - (w3 - w1) * x2) / 2.0
        
        a = a1**2 + a2**2 + dnm**2
        b = 2 * (a1 * b1 + a2 * (b2 - y1 * dnm) - z1 * dnm**2)
        c = (b2 - y1 * dnm)**2 + b1**2 + dnm**2 * (z1**2 - self.l**2)
        
        d = b**2 - 4.0 * a * c
        if d < 0:
            return None
            
        z0 = -0.5 * (b + math.sqrt(d)) / a
        x0 = (a1 * z0 + b1) / dnm
        y0 = (a2 * z0 + b2) / dnm
        
        return [x0, y0, z0]

def main(args=None):
    rclpy.init(args=args)
    node = Delta()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        sys.exit(0)

if __name__ == '__main__':
    main()