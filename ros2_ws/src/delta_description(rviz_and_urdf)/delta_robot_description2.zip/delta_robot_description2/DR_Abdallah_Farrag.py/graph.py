import pandas as pd
import matplotlib.pyplot as plt
import os

csv_filename = "delta_square_log_20260715_022736.csv"  

if not os.path.exists(csv_filename):
    print(f"Error: The file {csv_filename} was not found!")
    exit()

#read data from the file
df = pd.read_csv(csv_filename)

# ==========================================
fig, axs = plt.subplots(3, 1, figsize=(10, 12), sharex=True)
fig.suptitle('Delta Robot Joint Trajectory Tracking', fontsize=16, fontweight='bold')

#motor1
axs[0].plot(df['Time_s'], df['Target_M1'], label='Target Angle', color='navy', linestyle='--', linewidth=2.5)
axs[0].plot(df['Time_s'], df['Actual_M1'], label='Actual Angle', color='cyan', linewidth=2, alpha=0.8)
axs[0].set_ylabel('Angle (Degrees)', fontsize=12, fontweight='bold')
axs[0].set_title('Motor 1 (Base Joint)', fontsize=14)
axs[0].legend(loc='upper right')
axs[0].grid(True, linestyle=':', alpha=0.7)

# motor2
axs[1].plot(df['Time_s'], df['Target_M2'], label='Target Angle', color='darkred', linestyle='--', linewidth=2.5)
axs[1].plot(df['Time_s'], df['Actual_M2'], label='Actual Angle', color='orange', linewidth=2, alpha=0.8)
axs[1].set_ylabel('Angle (Degrees)', fontsize=12, fontweight='bold')
axs[1].set_title('Motor 2 (Left Joint)', fontsize=14)
axs[1].legend(loc='upper right')
axs[1].grid(True, linestyle=':', alpha=0.7)

# motor3
axs[2].plot(df['Time_s'], df['Target_M3'], label='Target Angle', color='darkgreen', linestyle='--', linewidth=2.5)
axs[2].plot(df['Time_s'], df['Actual_M3'], label='Actual Angle', color='limegreen', linewidth=2, alpha=0.8)
axs[2].set_ylabel('Angle (Degrees)', fontsize=12, fontweight='bold')
axs[2].set_xlabel('Time (Seconds)', fontsize=12, fontweight='bold')
axs[2].set_title('Motor 3 (Right Joint)', fontsize=14)
axs[2].legend(loc='upper right')
axs[2].grid(True, linestyle=':', alpha=0.7)


plt.tight_layout(rect=[0, 0.03, 1, 0.96]) 
image_name = "square106.png"
plt.savefig(image_name, dpi=300) 

print(f"Success The graph has been saved as '{image_name}'")

plt.show()