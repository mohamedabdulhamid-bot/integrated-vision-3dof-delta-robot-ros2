import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from visualization_msgs.msg import Marker
import math

class DeltaRobotIK(Node):
    def __init__(self):
        super().__init__('delta_ik_node')
        self.publisher_ = self.create_publisher(JointState, 'joint_states', 10)
        self.marker_pub = self.create_publisher(Marker, 'end_effector_marker', 10)
        self.timer = self.create_timer(0.1, self.timer_callback)

        # الأبعاد الفيزيائية (بالمتر)
        self.sb = 30.2 / 100.0  
        self.sp = 9.0/ 100.0  
        self.L = 32.0 / 100.0   
        self.l = 90.0 / 100.0   

        # حسابات ثوابت المثلثات الهندسية
        self.wb = self.sb * math.sqrt(3) / 6.0
        self.up = self.sp * math.sqrt(3) / 3.0
        self.wp = self.sp * math.sqrt(3) / 6.0

        self.a = self.wb - self.up
        self.b = (self.sp / 2.0) - (math.sqrt(3) / 2.0) * self.wb
        self.c = self.wp - 0.5 * self.wb

        # زوايا التوزيع
        self.phi = [math.radians(90), math.radians(210), math.radians(330)]

    def timer_callback(self):
        target_x = 0.0
        target_y = 0.0
        target_z = -0.800  # جربت لك هنا -0.8 عشان نشوف زوايا طبيعية
        
        # 1. حساب الزوايا (IK)
        angles = self.calculate_ik(target_x, target_y, target_z)
        
        if angles is None:
            self.get_logger().warn('Target point is Out of Workspace!')
            return
            
        theta_calc = angles  
        
        # 2. اختبار الدقة (FK)
        deg_angles = [math.degrees(t) for t in theta_calc]
        fk_result = self.calculate_fk(theta_calc[0], theta_calc[1], theta_calc[2])
        
        if fk_result is not None:
            self.get_logger().info('--------------------------------')
            self.get_logger().info(f'Target XYZ : ({target_x:.3f}, {target_y:.3f}, {target_z:.3f})')
            self.get_logger().info(f'FK Calc XYZ: ({fk_result[0]:.3f}, {fk_result[1]:.3f}, {fk_result[2]:.3f})')
            self.get_logger().info(f'Math Angles: M1={deg_angles[0]:.1f}°, M2={deg_angles[1]:.1f}°, M3={deg_angles[2]:.1f}°')
        
        # 3. حساب زوايا الكيعان (Elbows) بصرياً لمحاكي RViz
        elbow_calc = [0.0, 0.0, 0.0]
        for i in range(3):
            u_target = target_x * math.cos(self.phi[i]) + target_y * math.sin(self.phi[i])
            u_elbow = self.wb + self.L * math.cos(theta_calc[i])
            z_elbow = self.L * math.sin(theta_calc[i])
            
            u_platform = u_target + self.up
            z_platform = target_z  # صلحنا الإشارة دي عشان الكيعان متتقلبش لفوق
            
            delta_u = u_platform - u_elbow
            delta_z = z_platform - z_elbow
            alpha = math.atan2(delta_z, delta_u)
            
            elbow_calc[i] = alpha - theta_calc[i]

        # 4. المعايرة البصرية لـ RViz
        # رجعت الأوفست لـ 0 مبدئياً عشان نشوف الحركة الصافية للرياضيات
        motor_offset = 0.0  
        motor_dir = 1         
        
        elbow_offset = 0.0  
        elbow_dir = 1          
        
        theta1_out = (theta_calc[0] * motor_dir) + motor_offset
        theta2_out = (theta_calc[1] * motor_dir) + motor_offset
        theta3_out = (theta_calc[2] * motor_dir) + motor_offset
        
        elbow1_out = 0*((elbow_calc[0] * elbow_dir) + elbow_offset)
        elbow2_out = 0*((elbow_calc[1] * elbow_dir) + elbow_offset)
        elbow3_out = 0*((elbow_calc[2] * elbow_dir) + elbow_offset)

        # طباعة الزوايا اللي رايحة لـ RViz للتأكيد
        rviz_degs = [math.degrees(theta1_out), math.degrees(theta2_out), math.degrees(theta3_out)]
        self.get_logger().info(f'RViz Angles: M1={rviz_degs[0]:.1f}°, M2={rviz_degs[1]:.1f}°, M3={rviz_degs[2]:.1f}°')
        
        # 5. رسم المنصة (End-Effector)
        ee_marker = Marker()
        ee_marker.header.frame_id = "base_link"
        ee_marker.header.stamp = self.get_clock().now().to_msg()
        ee_marker.ns = "end_effector"
        ee_marker.id = 0
        ee_marker.type = Marker.CYLINDER  
        ee_marker.action = Marker.ADD
        
        ee_marker.pose.position.x = target_x
        ee_marker.pose.position.y = target_y
        ee_marker.pose.position.z = target_z
        ee_marker.pose.orientation.w = 1.0  
        
        ee_marker.scale.x = 0.12
        ee_marker.scale.y = 0.12
        ee_marker.scale.z = 0.01
        
        ee_marker.color.a = 1.0  
        ee_marker.color.r = 0.0
        ee_marker.color.g = 0.0
        ee_marker.color.b = 1.0
        
        self.marker_pub.publish(ee_marker)
        
        # 6. إرسال البيانات للمفاصل
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        
        msg.name = [
            'motor_1_joint', 'motor_2_joint', 'motor_3_joint',
            'elbow_1_joint', 'elbow_2_joint', 'elbow_3_joint'
        ]
        msg.position = [
            theta1_out, theta2_out, theta3_out,
            elbow1_out, elbow2_out, elbow3_out
        ]
        
        self.publisher_.publish(msg)

    def calculate_ik(self, x, y, z):
        z_calc = -z  # إرجاع Z للرياضيات القياسية
        
        theta = [0.0, 0.0, 0.0]
        
        E1 = 2 * self.L * (y + self.a)
        F1 = 2 * z_calc * self.L
        G1 = x**2 + y**2 + z_calc**2 + self.a**2 + self.L**2 + 2*y*self.a - self.l**2
        
        E2 = -self.L * (math.sqrt(3) * (x + self.b) + y + self.c)
        F2 = 2 * z_calc * self.L
        G2 = x**2 + y**2 + z_calc**2 + self.b**2 + self.c**2 + self.L**2 + 2*(x*self.b + y*self.c) - self.l**2
        
        E3 = self.L * (math.sqrt(3) * (x - self.b) - y - self.c)
        F3 = 2 * z_calc * self.L
        G3 = x**2 + y**2 + z_calc**2 + self.b**2 + self.c**2 + self.L**2 + 2*(-x*self.b + y*self.c) - self.l**2

        try:
            # === التعديل الجوهري هنا (+ بدل -) لاختيار وضع الـ Elbow Out ===
            theta[0] = 2 * math.atan((-F1 + math.sqrt(E1**2 + F1**2 - G1**2)) / (G1 - E1))
            theta[1] = 2 * math.atan((-F2 + math.sqrt(E2**2 + F2**2 - G2**2)) / (G2 - E2))
            theta[2] = 2 * math.atan((-F3 + math.sqrt(E3**2 + F3**2 - G3**2)) / (G3 - E3))
            return theta
        except ValueError:
            return None

    def calculate_fk(self, theta1, theta2, theta3):
        t = self.wb - self.up
        
        y1 = -(t + self.L * math.cos(theta1))
        z1 = -self.L * math.sin(theta1)
        
        y2 = (t + self.L * math.cos(theta2)) * math.sin(math.radians(30))
        x2 = (t + self.L * math.cos(theta2)) * math.cos(math.radians(30))
        z2 = -self.L * math.sin(theta2)
        
        y3 = (t + self.L * math.cos(theta3)) * math.sin(math.radians(30))
        x3 = -(t + self.L * math.cos(theta3)) * math.cos(math.radians(30))
        z3 = -self.L * math.sin(theta3)
        
        dnm = (y2 - y1) * x3 - (y3 - y1) * x2
        
        w1 = y1**2 + z1**2
        w2 = x2**2 + y2**2 + z2**2
        w3 = x3**2 + y3**2 + z3**2
        
        a1 = (z2 - z1) * (y3 - y1) - (z3 - z1) * (y2 - y1)
        b1 = -((w2 - w1) * (y3 - y1) - (w3 - w1) * (y2 - y1)) / 2.0
        
        a2 = -(z2 - z1) * x3 + (z3 - z1) * x2
        b2 = ((w2 - w1) * x3 - (w3 - w1) * x2) / 2.0
        
        a = a1**2 + a2**2 + dnm**2
        b = 2 * (a1 * b1 + a2 * (b2 - y1 * dnm) - z1 * dnm**2)
        c = (b2 - y1 * dnm)**2 + b1**2 + dnm**2 * (z1**2 - self.l**2)
        
        d = b**2 - 4.0 * a * c
        if d < 0:
            return None
            
        z0 = -0.5 * (b + math.sqrt(d)) / a
        x0 = (a1 * z0 + b1) / dnm
        y0 = (a2 * z0 + b2) / dnm
        
        # قلبنا إشارة الـ Z هنا عشان ترجع تتطابق مع ROS
        return [x0, y0, -z0]

def main(args=None):
    rclpy.init(args=args)
    ik_node = DeltaRobotIK()
    rclpy.spin(ik_node)
    ik_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()